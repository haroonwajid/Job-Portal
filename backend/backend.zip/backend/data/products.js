const products = [
  {
    name: "Cycle",
    imageUrl:
      "https://images.unsplash.com/photo-1583467875263-d50dec37a88c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80",
    description:
      "Cycling is a fun and effective way to improve your cardiovascular health and stay active. Our cycles are designed with comfort and performance in mind, featuring adjustable seat and handlebars for a customized fit. With a sturdy and durable frame, these cycles provide a smooth and stable ride, allowing you to focus on your workout. Whether you're a beginner or an experienced cyclist, our cycles are perfect for indoor or outdoor use, providing a challenging and effective workout for all fitness levels. Get ready to pedal your way to a healthier lifestyle with our high-quality and reliable cycles.",
    price: 850,
    countInStock: 15,
  },
  {
    name: "Tennis Racquet",
    imageUrl:
      "https://images.unsplash.com/photo-1560012057-4372e14c5085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=774&q=80",
    description:
      "A tennis racquet is a vital tool for anyone looking to take their tennis game to the next level. Our racquets are designed with performance and comfort in mind, featuring a lightweight and sturdy construction that delivers excellent power and precision on the court. With a comfortable grip and optimal string tension, these racquets provide excellent control and maneuverability, allowing you to hit your best shots every time. Whether you're a beginner or an experienced player, our tennis racquets are perfect for improving your game and taking on your opponents with confidence. Get ready to elevate your tennis skills with our high-quality and reliable racquets.",
    price: 1099,
    countInStock: 10,
  },
  {
    name: "Cricket Bat",
    imageUrl:
      "https://plus.unsplash.com/premium_photo-1679690884082-eaba9eccdcb5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=484&q=80",
    description:
      "A cricket bat is an essential tool for any cricketer looking to score big on the pitch. Our cricket bats are made with high-quality materials and designed for maximum power and control, allowing you to hit your best shots with ease. With a comfortable grip and balanced weight distribution, these bats provide excellent maneuverability and precision, making them perfect for both beginner and experienced players. Whether you're playing in a casual game with friends or competing at a professional level, our cricket bats are the perfect choice for improving your game and hitting those winning runs. Don't settle for less, choose our reliable and high-quality cricket bats for your next game.",
    price: 1300,
    countInStock: 5,
  },
  {
    name: "Skipping Rope",
    imageUrl:
      "https://images.unsplash.com/photo-1516876345887-6dd74f80787a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=580&q=80",
    description:
      "A skipping rope is an essential fitness accessory for anyone looking to improve their cardio and agility. Our skipping rope is made with high-quality materials and features adjustable length, allowing it to be customized to your height and preferences. The lightweight design and comfortable handles make it easy to use for extended periods of time, while the durable construction ensures long-lasting use. Whether you're a beginner or an experienced jumper, this skipping rope is perfect for improving your endurance, coordination, and overall fitness. Add it to your workout routine today and start seeing the benefits of this simple yet effective exercise tool.",
    price: 50,
    countInStock: 25,
  },
  {
    name: "Dumbells",
    imageUrl:
      "https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80",
    description:
      "Dumbbell weights are a must-have for any home gym or workout routine. Our 5kg and 2.5kg dumbbell weights are perfect for a variety of exercises, from bicep curls to overhead presses. Made with high-quality materials and featuring a comfortable grip, these weights are built to last and provide a comfortable workout experience. Whether you're a beginner or an experienced weightlifter, these dumbbell weights are a great addition to your fitness routine. Get ready to see results and take your workouts to the next level with these versatile and durable weights.",
    price: 233,
    countInStock: 4,
  },
  {
    name: "Adidas Orange Shoes",
    imageUrl:
      "https://images.unsplash.com/photo-1580980379292-082d6126499c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=833&q=80",
    description:
      "These orange Adidas shoes are the perfect blend of fashion and function. With a bold and eye-catching orange color, they are sure to make a statement wherever you go. Made with high-quality materials, these shoes offer superior comfort and support for all-day wear. Whether you're hitting the gym or running errands, these Adidas shoes will keep you looking stylish and feeling comfortable. Don't miss out on adding this trendy and versatile pair of shoes to your collection.",
    price: 140,
    countInStock: 10,
  },
  {
    name: "Adidas Yellow Shoes",
    imageUrl:
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1528&q=80",
    description:
      "These yellow Adidas shoes are a perfect combination of style and comfort. With a vibrant yellow color and sleek design, they are sure to catch the eye of anyone passing by. Made with high-quality materials, these shoes provide excellent support and durability for everyday wear. Whether you're hitting the gym or running errands, these Adidas shoes will keep you looking and feeling great. Don't miss out on this must-have addition to your shoe collection.",
    price: 1099,
    countInStock: 10,
  },
];

module.exports = products;
